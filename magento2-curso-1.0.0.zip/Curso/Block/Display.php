<?php
namespace Magento2\Curso\Block;
class Display extends \Magento\Framework\View\Element\Template
{
	public function __construct(\Magento\Framework\View\Element\Template\Context $context)
	{
		parent::__construct($context);
	}

	public function diHola()
	{
		return __("Hola, Holita vecinillo");
	}
}
