<?php
namespace magento2\Curso\Controller\Curso;

class Magento extends \Magento\Framework\App\Action\Action
{
    public function __construct(
        \Magento\Framework\App\Action\Context $context)
    {
        return parent::__construct($context);
    }
    public function execute()
    {
        echo 'Curso de Magento2, el Mejor del Mundo!!!!';
        exit;
    } 
}